export const isEmpty = (value: string): boolean => value.trim().length > 0
