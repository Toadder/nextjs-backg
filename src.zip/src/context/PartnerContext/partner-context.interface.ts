export interface IPartnerContext {
	message: string
	setMessage: (msg: string) => void
}
