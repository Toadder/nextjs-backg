export interface IJournalContext {
	isJournalLoaded: boolean
	loadJournal: () => void
}
