export const INIT_SLIDES_PER_VIEW: number = 3
