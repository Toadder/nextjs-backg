export const ARTICLES_TO_LOAD: number = 5

export const COMMENTS_TO_SHOW: number = 8

export const COMMENT_NAME_LENGTH: number = 26

export const MONTHS: string[] = [
	'января',
	'февраля',
	'марта',
	'апреля',
	'мая',
	'июня',
	'июля',
	'августа',
	'сентября',
	'октября',
	'ноября',
	'декабря'
]
