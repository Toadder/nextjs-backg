import JournalLoadMore from './JournalLoadMore'
import JournalLoadFilter from './JournalLoadFilter'

export default { JournalLoadMore, JournalLoadFilter }
