import { ReactNode } from 'react'

export interface IDescription {
	children?: ReactNode
	htmlContent?: string
	className?: string
}
