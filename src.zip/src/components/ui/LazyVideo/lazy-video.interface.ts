export interface ILazyVideo {
	videoMp4?: string;
	videoWebm?: string;
	className?: string;
	spinnerClassName?: string;
}