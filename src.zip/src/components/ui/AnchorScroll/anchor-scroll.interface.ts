export interface IAnchorScroll {
	paramName: string
}
