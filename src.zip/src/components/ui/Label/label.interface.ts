export interface ILabel {
	text: string
	className?: string
}
