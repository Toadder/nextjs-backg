export interface IAnchorBtn {
	blockId: string
	text: string
	className?: string
}
