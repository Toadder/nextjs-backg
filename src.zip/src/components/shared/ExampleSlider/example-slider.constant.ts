export const INITIAL_SLIDES_PER_VIEW: number = 4
