import { PostTypeSeo } from './grahpql.types'

export interface IMetadata extends PostTypeSeo {}
