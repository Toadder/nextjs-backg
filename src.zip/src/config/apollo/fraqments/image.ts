export const imageFragment = `
	fragment ImageFragment on MediaItem {
		sourceUrl
		altText
	}
`
