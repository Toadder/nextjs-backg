export const menuFragment = `
	fragment MenuFragment on MenuItem {
		id
		label
		url
		path
	}
`
