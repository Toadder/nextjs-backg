export const APP_EVENT_WIDGET_CLASS_NAME: string = 'aeWidgetBtn'
export const APP_EVENT_ACTIVE_WIDGET_ID: string = 'aeWidgetOpen'
